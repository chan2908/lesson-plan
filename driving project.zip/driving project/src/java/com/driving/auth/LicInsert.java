/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author chandra
 */
public class LicInsert {
    public static void main(String args[])
    {
     byte[] fileBytes;
        String query;
        String connectionString =
                "jdbc:sqlserver://hema.database.windows.net:1433;database=hema;user=hema@hema;password=Password@1997;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";

        // Declare the JDBC objects.
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        String temp=null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(connectionString);

            File file = new File("E:\\project\\img\\c.jpg");

            FileInputStream fis = new FileInputStream(file);
            // len = (int)file.length();

           query = ("insert into License VALUES(?,?,?,?,?,?,?,?,?,?)");
          
            pstmt = connection.prepareStatement(query);
            
            pstmt.setString(1,"chandralekha");
            pstmt.setString(2, "Neelamegan");
            Date date;
            date = new Date(0);
            pstmt.setDate( 3 , Date.valueOf("1996-12-26"));
            pstmt.setString(4,"AB+");
            pstmt.setString(5,"TN54321487594075");
            pstmt.setDate(6,Date.valueOf("2037-09-12"));
            pstmt.setString(7,"motor_cycle");
            pstmt.setString(8,"gundur mettu street,chengalpattu");
            pstmt.setString(9,"3333444989898");
            
          // Method used to insert a stream of bytes
            pstmt.setBinaryStream(10, fis);
             pstmt.executeUpdate();

        }
        catch (FileNotFoundException | ClassNotFoundException | SQLException e)
        {
        }
    }
    
}
