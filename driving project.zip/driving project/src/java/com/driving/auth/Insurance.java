/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author chandra
 */
public class Insurance {
     public static void main(String arg[]) throws SQLException {
  String connectionString =
                "jdbc:sqlserver://hema.database.windows.net:1433;database=hema;user=hema@hema;password=Password@1997;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";

        // Declare the JDBC objects.
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        String temp=null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(connectionString);
     
      
    
      // create a sql date object so we can use it in our INSERT statement
      

      // the mysql insert statement
      String query = " insert into insurance (Registration_no,PeriodOfInsurance)"
        + " values (?,?)";

      // create the mysql insert preparedstatement
      pstmt = connection.prepareStatement(query);
      //TN33R5584
      pstmt.setString(1,"TN44R5584");
      pstmt.setString (2, "From :16-02-2016 to 17-02-2017");       
      /*From 00:00 :25-Aug-2010 to 24-Aug-2011 midnight || TN33R5584  
              | From 00:00 :20-Dec-2015 to 25-Aug-2016 midnight  |
                      | TN44R5584         |  
              From 00:00 :15-feb-2015 to 29-Aug-2016 midnight
              */
      // execute the preparedstatement
      pstmt.execute();
      
      connection.close();
    }
    catch (ClassNotFoundException | SQLException e)
    {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  }         
}
