/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

/**
 *
 * @author chandra
 */
import java.io.*;
import java.sql.*;

public class ImageInsert {
    public static void main(String arg[]) {
     //   int len;
        //FileInputStream fis;
        byte[] fileBytes;
        String query;
        String connectionString =
                "jdbc:sqlserver://hema.database.windows.net:1433;database=hema;user=hema@hema;password=Password@1997;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";

        // Declare the JDBC objects.
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        String temp=null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(connectionString);

            File file = new File("E:\\project\\img\\anna.jpg");

            FileInputStream fis = new FileInputStream(file);
            // len = (int)file.length();

           query = ("insert into REGISTRATION VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
          
            pstmt = connection.prepareStatement(query);
             
            pstmt.setString(1,"TN19AC2297");
            pstmt.setString(2, "Devajagadesh");
            pstmt.setString (3,"No:140 padasalai st,thirukalukundram");
            Date date;
            date = new Date(0);
            pstmt.setDate( 4 , Date.valueOf("2013-02-20"));
            pstmt.setString(5," RTO,Anna Nagar,Chengalpattu,Chennai-603001"  );
            pstmt.setString( 6,"motor_cycle" );
            pstmt.setString( 7,"bajaj" );
            pstmt.setString( 8,"Petrol" );
            pstmt.setDate( 9,Date.valueOf("2014-08-29"));
            pstmt.setInt( 10,2 );
            pstmt.setString( 11,"7026FA584" );
            pstmt.setString( 12,"7000A515" );
            pstmt.setString( 13,"black" );
            pstmt.setInt( 14,2 );
            pstmt.setString( 15,"64" );

            // Method used to insert a stream of bytes
            pstmt.setBinaryStream(16, fis);
            pstmt.executeUpdate();

        }
        catch (FileNotFoundException | ClassNotFoundException | SQLException e)
        {
        }
        }

   
}

