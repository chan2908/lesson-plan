/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

/**
 *
 * @author chandra
 */
import java.sql.*;
import com.microsoft.sqlserver.jdbc.*; 
import java.io.*;
import java.util.*;
public class image {
  


 public static void main(String arg[])
        {
                int len;
	       byte[] fileBytes;
                String query;
               String connectionString =  
                    "jdbc:sqlserver://hema.database.windows.net:1433;database=hema;user=hema@hema;password=Password@1997;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";  

                // Declare the JDBC objects.  
               Connection connection = null;  
                Statement statement = null;   
                ResultSet resultSet = null;  
                String temp=null;
            //    PreparedStatement pstmt = null;  

                try {  
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    connection = DriverManager.getConnection(connectionString);  
                 
                        File file = new File("download.png");
                        FileInputStream fis = new FileInputStream(file);
                        len = (int)file.length();
 
                     //   query = ("insert into insert1 VALUES(?,?,?)");
						 query = "select image from insert1";                      
/*pstmt = connection.prepareStatement(query);
                        pstmt.setString(1,file.getName());
                        pstmt.setInt(2, len);
   
                        // Method used to insert a stream of bytes
                        pstmt.setBinaryStream(3, fis, len); 
                        pstmt.executeUpdate();*/
					   Statement state = connection.createStatement();
                         ResultSet rs = state.executeQuery(query);
                         if (rs.next())
                        {
                                  fileBytes = rs.getBytes(1);
                                  OutputStream targetFile=  
                                  new FileOutputStream(
                                       "d://new.JPG");
 
                                  targetFile.write(fileBytes);
                                  targetFile.close();
                        }        	
						
 
                }
                catch (Exception e)
                {
                        e.printStackTrace();
                }
 }}
    

