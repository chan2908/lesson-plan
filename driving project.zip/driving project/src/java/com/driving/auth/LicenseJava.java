/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author chandra
 */
public class LicenseJava {
    public String isValid(String arg1,String path) {
      String ConnectionString =  
                    "jdbc:sqlserver://hema.database.windows.net:1433;database=hema;user=hema@hema;password=Password@1997;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";  

                
                 // Declare the JDBC objects.  
                Connection connection = null;  
                Statement statement = null;   
                ResultSet resultSet = null;  
                 String temp=null;
                 byte[] fileBytes;
                
                   try
                {
                     // Establish the connection
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    connection = DriverManager.getConnection(ConnectionString);  
                  
                    
                    
                     String SelectSql = "SELECT Name,Father_Name,Date_Of_Birth,Blood_Group,license_no,validity,Type_of_vehicle,permanent_address,Aadhar_No,image FROM License where Aadhar_No='"+arg1+"';";
                    
                       statement = connection.createStatement();  
                      resultSet = statement.executeQuery(SelectSql);
                      
                       // Print results from select statement  
                    while (resultSet.next())   
                    {  
                        System.out.println(resultSet.getString(1) + "$"  + resultSet.getString(2) + "$"  + resultSet.getString(3) + "$"  + resultSet.getString(4) + "$"  + resultSet.getString(5) + "$"  + resultSet.getString(6) + "$"  + resultSet.getString(7) + " "  + resultSet.getString(8)  + " "  + resultSet.getString(9));  
                        temp=resultSet.getString(1) + "$"  + resultSet.getString(2) + "$"  + resultSet.getString(3) + "$"  + resultSet.getString(4) + "$"  + resultSet.getString(5) + "$"  + resultSet.getString(6) + "$"  + resultSet.getString(7) + "$"  + resultSet.getString(8)  + "$"  + resultSet.getString(9);
                    fileBytes = resultSet.getBytes(10);
                        OutputStream targetFile= new FileOutputStream(path+"//pic.jpg");
 
                                  targetFile.write(fileBytes);
                                  targetFile.close();     
                        
                        
                    }  
                }  
                catch (IOException | ClassNotFoundException | SQLException e) {  
                }  
                finally {  
                          if (resultSet != null) try { resultSet.close(); } catch(SQLException e) {}  
                    if (statement != null) try { statement.close(); } catch(SQLException e) {}  
                    if (connection != null) try { connection.close(); } catch(SQLException e) {}  
                       }  
        return temp;

                }   
    }
    

