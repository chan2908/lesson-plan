/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author chandra
 */
public class RcBook extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String Registration=request.getParameter("Registration");
        
        //find war file path 
        //request-servlet req.obj,is to take the servlet context that means 
        //at running service instance,  
        String appPath = request.getServletContext().getRealPath("");
          
        RcBookjava rc=new RcBookjava();
        String temp=rc.isValid(Registration,appPath);
        
        
        String csvsplit="\\$";
        
        String[] details=temp.split(csvsplit);
       
        request.setAttribute("reg", details[0]);
        request.setAttribute("own", details[1]);
        request.setAttribute("addr", details[2]);
        request.setAttribute("date", details[3]);
        request.setAttribute("office", details[4]);
        request.setAttribute("motor", details[5]);
        request.setAttribute("maker", details[6]);
        request.setAttribute("type", details[7]);
        request.setAttribute("mani", details[8]);
        request.setAttribute("stoke", details[9]);
        request.setAttribute("engine", details[10]);
        request.setAttribute("chase", details[11]);
        request.setAttribute("color", details[12]);
        request.setAttribute("tiers",details[13]);
        request.setAttribute("measure",details[14]);
        request.setAttribute("period",details[16]);
        
        
      //  request.setAttribute("reg", Registration);
                RequestDispatcher rd=request.getRequestDispatcher("RCbookdet.jsp");
            rd.forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
