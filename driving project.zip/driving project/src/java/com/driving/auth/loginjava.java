/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driving.auth;

import java.sql.*;
import com.microsoft.sqlserver.jdbc.*;  

/**
 *
 * @author chandra
 */
public class loginjava {
     public String isValid(String arg1)
     {
         // Create a variable for the connection string
      String ConnectionString =  
                    "jdbc:sqlserver://hema.database.windows.net:1433;database=hema;user=hema@hema;password=Password@1997;encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";  

                 // Declare the JDBC objects.  
                Connection connection = null;  
                Statement statement = null;   
                ResultSet resultSet = null;  
                 String temp=null;
                
                try
                {
                     // Establish the connection
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    connection = DriverManager.getConnection(ConnectionString);  
                     
                    // Create and execute an SQL statement that returns some data
                     String SelectSql = "SELECT password from login where username='"+arg1+"';";
                    
                     //A Statement is an interface that represents a SQL statement.
                      //Connection object to create a Statement object
                      
                    statement = connection.createStatement(); 
                  //  execute Statement objects, and they generate ResultSet objects
                    resultSet = statement.executeQuery(SelectSql);
                    
                    // Iterate through the data in the result set and display it 
                    while (resultSet.next())   
                    {  
                       
                        temp = resultSet.getString(1);
                       
                    }
                }
                // Handle any errors that may have occurred.
	  catch (Exception e) {  
                    e.printStackTrace();  
                }  
                finally {  
                    // Close the connections after the data has been handled.  
      
                    if (resultSet != null) try { resultSet.close(); } catch(SQLException e) {}  
                    if (statement != null) try { statement.close(); } catch(SQLException e) {}  
                    if (connection != null) try { connection.close(); } catch(SQLException e) {}  
                }  
         return temp;
     }
}
                       

  
